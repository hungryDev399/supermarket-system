/*#pragma once
#include "pch.h"
#include "openai.hpp"
#include <nlohmann/json.hpp>
void talkToGPT();*/