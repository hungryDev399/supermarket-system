#include "pch.h"
/*template <typename T, size_t S>
class Array {
	T = m_data[S];

public:
	T& operator[](S i){ 
		
#if (index >= S)
		__debugbreak()
#endif
		return m_data[i]
	}


	const T& operator[](size_t i) const { 
#if (index >= S)
		__debugbreak()
#endif
		return m_data[i] 
	}

	constexpr size_t size() const { return S; }
};


class Arrayy {
	int* m_data;
public:
	Arrayy(int size) {
		m_data = (int*)alloca(size * sizeof(int));
	}
};


int main() {
	int size = 10;
	
}*/